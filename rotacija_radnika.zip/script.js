const rotationOrder = ["1L", "2L", "3L", "4L", "1D", "2D", "3D", "4D", "5"];
let workerNames = {
    "1L": "Ivana",
    "2L": "Marko",
    "3L": "Amar",
    "4L": "Jasna",
    "1D": "Lejla",
    "2D": "Petar",
    "3D": "Sara",
    "4D": "Nermin",
    "5": "Aida"
};

let positionCounts = {};
let rotationCounter = 0;
const maxRotations = 10;

for (let pos of rotationOrder) {
    for (let name of Object.values(workerNames)) {
        if (!positionCounts[name]) {
            positionCounts[name] = {};
        }
        positionCounts[name][pos] = 0;
    }
}

updatePositionCounts();

function updateUI() {
    for (let pos of rotationOrder) {
        document.getElementById(pos).innerText = workerNames[pos];
    }
}

function updatePositionCounts() {
    for (let pos of rotationOrder) {
        const name = workerNames[pos];
        positionCounts[name][pos]++;
    }
}

function rotate() {
    const last = workerNames["5"];
    for (let i = rotationOrder.length - 1; i > 0; i--) {
        workerNames[rotationOrder[i]] = workerNames[rotationOrder[i - 1]];
    }
    workerNames["1L"] = last;

    updateUI();
    updatePositionCounts();

    rotationCounter++;
    if (rotationCounter >= maxRotations) {
        clearInterval(rotationInterval);
        showSummary();
    }
}

function showSummary() {
    const summaryDiv = document.createElement("div");
    summaryDiv.style.marginTop = "40px";

    let html = "<h3>Statistika pozicija nakon 10 smjena</h3><table border='1' style='margin:auto; border-collapse: collapse;'>";
    html += "<tr><th>Radnik</th>";
    for (let pos of rotationOrder) {
        html += `<th>${pos}</th>`;
    }
    html += "</tr>";

    for (let [name, positions] of Object.entries(positionCounts)) {
        html += `<tr><td>${name}</td>`;
        for (let pos of rotationOrder) {
            html += `<td>${positions[pos]}</td>`;
        }
        html += "</tr>";
    }

    html += "</table>";
    summaryDiv.innerHTML = html;
    document.body.appendChild(summaryDiv);
}

const rotationInterval = setInterval(rotate, 3000);
updateUI();
